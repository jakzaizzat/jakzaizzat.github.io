### Version 3.100
- Now with four set of figures: tabular lining (default), tabular oldstyle, proportional lining, proportional oldstyle.
- fixed kcommaaccent (ķ) accent positioning (thanks @kalapi).
- Deleted some open paths in .glyphs files.